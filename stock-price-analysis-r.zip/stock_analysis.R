# Stock Price Analysis using R

# Load necessary library
install.packages("quantmod")
library(quantmod)

# Fetch stock data for Apple Inc.
getSymbols("AAPL", src = "yahoo", from = "2022-01-01", to = Sys.Date())
head(AAPL)

# Calculate Simple Moving Averages
sma50 <- SMA(Cl(AAPL), n = 50)
sma200 <- SMA(Cl(AAPL), n = 200)

# Plot the stock price with SMAs
chartSeries(AAPL, theme = chartTheme("white"), TA = NULL)
addSMA(n = 50, col = "blue")
addSMA(n = 200, col = "red")
